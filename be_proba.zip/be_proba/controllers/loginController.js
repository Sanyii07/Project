const Vasarlo = require('../models/vasarlok'); // Vasarlo modell importálása

// Bejelentkezési oldal megjelenítése
exports.getLoginPage = (req, res) => {
    res.render('login', {
        title: 'Bejelentkezés',
        loginMessage: 'Kérlek, jelentkezz be!'
    });
};

// Bejelentkezés feldolgozása
exports.loginUser = async (req, res) => {
    try {
        const { username, password } = req.body;
        //username = "brb";
        // Ellenőrizzük, hogy a felhasználó létezik-e
        const user = await Vasarlo.findOne({ where: { email: username } });
        console.log(user);
        if (!user) {
            return res.render('login', {
                loginMessage: 'Nincs ilyen felhasználó!'
            });
        }

        // Ha a jelszó és felhasználónév helyes, átirányítjuk a felhasználót egy védett oldalra
        if (user.jelszo === password) {
            res.redirect('/'); // Átirányítás egy védett oldalra, mint a vezérlőpult
        } else {
            return res.render('login', {
                loginMessage: 'Hibás jelszó!'
            });
        }

    } catch (err) {
        console.error(err);
        res.status(500).send('Hiba történt a bejelentkezés során.');
    }
};

