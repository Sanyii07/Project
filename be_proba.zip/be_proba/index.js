require('dotenv').config();
const express = require('express');
const app = express();
const sequelize = require('./config/adatbazis');
const loginRoutes = require('./routes/loginRoutes');
const regRoutes = require('./routes/regRoutes');




const termRoutes = require('./routes/termRoutes');
const vasaRoutes = require('./routes/vasaRoutes');
const rendRoutes = require('./routes/rendRoutes');


app.set('view engine', 'ejs');
app.set('views', './views');

const path = require('path');

app.set('views', path.join(__dirname, 'views'));

app.use(express.urlencoded({ extended: true }));

app.use(express.static('public'));

app.use(loginRoutes);
app.use(regRoutes);

// app.use('/', carRoutes);
// app.use('/rentals',rentalRoutes);


const Rend = require('./models/rendelesek');
const Term = require('./models/termekek');
const Vasa = require('./models/vasarlok');


sequelize.sync({ force: false }).then(async () => {
    console.log('Adatbázis feltöltése alapadatokkal');

    
   
    

    //await Term.create({ id: 1, nev: 'Corolla', ar: 2020, keszlet: true, leiras: 'bffb', marka: 'brbh', kategoria: 'gergh' });

    
    //await Vasa.create({ id: 1, nev: 'bfrbd', email: 'brb', telszam: 131, jelszo: 'brbe' });

    //await Rend.create({ id: 1, vasarloId: 1, termekId: 1, egysegar: true, idopont: Date.now(), mennyiseg: 3 });
    
    

    // Weboldal kiszolgálása
    app.get('/', (req, res) => {
        const headerText = "Év végi Projekt";
        const imageSrc = 'kep3.jpg'; // Alapértelmezett kép
        const navLinks = [
            { href: '/kapcsolat', text: 'Kapcsolat' },
            { href: '/tortenet', text: 'Történetünk' }
        ];
        const loginHref = '/login';
        const loginText = 'Bejelentkezés';

        // Mindezeket az adatokat átadjuk az EJS-nek
        res.render('index', { 
            headerText, 
            imageSrc, 
            navLinks, 
            loginHref, 
            loginText 
        });
    });




    app.listen(3000, () => {
        console.log('A szerver elérhető: http://localhost:3000');
    });
});
