const express = require('express');
const router = express.Router();
const authController = require('../controllers/loginController');

// /login útvonal kiszolgálása
router.get('/login', authController.getLoginPage);

// Bejelentkezés feldolgozása (POST kérés)
router.post('/auth', authController.loginUser);

module.exports = router;


