const Term = require('../models/termekek');

exports.getWebshop = async (req, res) => {
    try {
        const products = await Term.findAll();
        res.render('webshop', { products });
    } catch (error) {
        console.error('Hiba a webshop betöltésekor:', error);
        res.status(500).send('Hiba történt a webshop betöltésekor');
    }
};