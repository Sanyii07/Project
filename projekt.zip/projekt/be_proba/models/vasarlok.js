const { DataTypes } = require('sequelize');
const sequelize = require('../config/adatbazis');

const Vasarlok = sequelize.define('vasarlok', {
  id: {
    type: DataTypes.INTEGER,
    allowNull: false,
    autoIncrement: true,
    primaryKey: true,
  },
  nev: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  email: {
    type: DataTypes.STRING,
    allowNull: false,
    unique: true,
  },
  telszam: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  jelszo: {
    type: DataTypes.STRING,
    allowNull: false,
  },
}, {
  freezeTableName: true,
  timestamps: false,
});


module.exports = Vasarlok;

