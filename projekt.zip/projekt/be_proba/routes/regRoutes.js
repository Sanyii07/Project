const express = require('express');
const regController = require('../controllers/regController'); // Regisztrációs controller importálása
const router = express.Router();

// Regisztrációs oldal megjelenítése (GET kérés)
router.get('/register', regController.getRegisterPage);

// Regisztrációs adatok feldolgozása (POST kérés)
router.post('/register', regController.registerUser);

module.exports = router;
