// controllers/homeController.js
const Rend = require('../models/rendelesek');
const Term = require('../models/termekek');
const Vasa = require('../models/vasarlok');

const homePage = (req, res) => {
    const headerText = "GymShop";
    const imageSrc = "/img/logokep.jpg"; // Alapértelmezett kép
    const navLinks = [
        { href: '/kapcsolat', text: 'Kapcsolat' },
        { href: '/tortenet', text: 'Történetünk' }
    ];
    const loginHref = req.session.user ? '/logout' : '/login';
    const loginText = req.session.user ? 'Kijelentkezés' : 'Bejelentkezés';

    res.render('index', { 
        headerText, 
        imageSrc, 
        navLinks, 
        loginHref, 
        loginText,
        loggedInUser: req.session.user || null // Átadjuk a bejelentkezett felhasználó adatait
    });
};

module.exports = { homePage };
