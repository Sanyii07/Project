const Vasarlo = require('../models/Vasarlok'); // Vasarlo modell importálása

// Bejelentkezési oldal megjelenítése
exports.getLoginPage = (req, res) => {
    res.render('login', {
        title: 'Bejelentkezés',
        loginMessage: 'Kérlek, jelentkezz be!'
    });
};

// Bejelentkezés feldolgozása
exports.loginUser = async (req, res) => {
    try {
        console.log(req.session);

        const { username, password } = req.body;

        // Ellenőrizzük, hogy a felhasználó létezik-e
        const user = await Vasarlo.findOne({ where: { email: username } });

        if (!user) {
            return res.render('login', {
                loginMessage: 'Nincs ilyen felhasználó!'
            });
        }

        // Ha a jelszó helyes
        if (user.jelszo === password) {
            // Felhasználói adatok mentése a session-be
            req.session.user = { 
                username: user.nev, 
                email: user.email,
                admin: user.admin  // Mentjük el az admin státuszt
            };

            // Ha admin, irányíthatjuk más oldalra, ha nem, akkor csak a főoldalra
            if (user.admin === 1) {
                // Admin jogú felhasználó, további admin funkciókat biztosíthatunk itt
                console.log('Admin felhasználó jelentkezett be');
            }

            // Átirányítjuk a felhasználót a főoldalra vagy védett oldalra
            return res.redirect('/');  // Itt marad a főoldal, ha nem akarunk új oldalt
        } else {
            return res.render('login', {
                loginMessage: 'Hibás jelszó!'
            });
        }
    } catch (err) {
        console.error(err);
        res.status(500).send('Hiba történt a bejelentkezés során.');
    }
};

exports.getIndexPage = (req, res) => {
    res.render('index', {
        navLinks: [
            { href: '/about', text: 'Rólunk' },
            { href: '/contact', text: 'Kapcsolat' }
        ],
        headerText: 'Üdvözlünk!',
        imageSrc: '/img/logo.png',
        loginHref: req.session.user ? '/logout' : '/login',
        loginText: req.session.user ? 'Kijelentkezés' : 'Bejelentkezés',
        loggedInUser: req.session.user || null
    });
};
