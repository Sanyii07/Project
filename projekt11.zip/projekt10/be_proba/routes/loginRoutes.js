const express = require('express');
const router = express.Router();
const authController = require('../controllers/loginController');

// /login útvonal kiszolgálása
router.get('/login', authController.getLoginPage);

router.get('/logout', (req, res) => {
    req.session.destroy(); // Session törlése
    res.redirect('/login'); // Visszairányítás a bejelentkezési oldalra
});


// Bejelentkezés feldolgozása (POST kérés)
router.post('/auth', authController.loginUser);

module.exports = router;


