const Termek = require('../models/termekek'); // Vasarlo modell importálása

// Regisztrációs oldal megjelenítése (GET kérés)
exports.getOperator = (req, res) => {
    res.render('operator');
};

// Regisztrációs adatok feldolgozása (POST kérés)
exports.operatorTerm = async (req, res) => {
    try {
        const { nev, ar, keszlet, leiras,marka,kategoria,kep } = req.body;

        // Ellenőrizzük, hogy minden mező ki van-e töltve
        if (!nev || !ar || !keszlet || !leiras || !marka || !kategoria||!kep) {
            return res.status(400).send('Minden mezőt ki kell tölteni!');
        }
        
        // Új vásárló létrehozása a vasarlok táblában
        await Termek.create({
            nev,
            ar,
            keszlet,
            leiras, 
            marka,
            kategoria,
            kep
        });

        
        res.redirect('/operator'); 
        
    } catch (err) {
        console.error('Hiba:', err);
        res.status(500).send('Hiba történt a termék hozzáadása során.');
    }
    
};
