const express = require('express');
const userController = require('../controllers/profileController');
const router = express.Router();

// Profil oldal route
router.get('/profile', userController.getProfilePage);

module.exports = router;
