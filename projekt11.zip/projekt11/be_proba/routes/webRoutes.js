const express = require('express');
const router = express.Router();
const webController = require('../controllers/webController');

router.get('/webshop', webController.getWebshop);
router.get('/termek/:id', webController.getTermek);
router.post('/termek/torles/:id', webController.deleteTermek); // Új törlési útvonal
router.post('/kosar/hozzaad/:id', webController.addToKosar); // Kosárhoz adás
router.get('/kosar', webController.getKosar); // Kosár oldal
router.post('/kosar/torles/:id', webController.removeFromKosar); // Kosárból való eltávolítás

module.exports = router;
