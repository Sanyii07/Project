const Vasarlo = require('../models/Vasarlok'); 

exports.getProfilePage = async (req, res) => {
    try {
        if (!req.session.user) {
            return res.redirect('/login');  
        }

        const userEmail = req.session.user.email;
        const user = await Vasarlo.findOne({ where: { email: userEmail } });

        if (!user) {
            return res.status(404).send('Felhasználó nem található!');
        }

        // Csak az alapadatokat adjuk át a profil oldalnak
        res.render('profile', {
            user: user,
            loggedInUser: req.session.user
        });
    } catch (error) {
        console.error(error);
        res.status(500).send('Hiba történt a profil lekérésekor.');
    }
};
