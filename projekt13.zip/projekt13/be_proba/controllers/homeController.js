const Rend = require('../models/rendelesek');
const Term = require('../models/termekek');
const Vasa = require('../models/Vasarlok');

const homePage = (req, res) => {
    const headerText = "GymShop";
    const imageSrc = "/img/logokep.jpg"; 
    const navLinks = [
        { href: '/kapcsolat', text: 'Kapcsolat' },
        { href: '/tortenet', text: 'Történetünk' }
    ];
    const loginHref = req.session.user ? '/logout' : '/login';
    const loginText = req.session.user ? 'Kijelentkezés' : 'Bejelentkezés';

    res.render('index', { 
        headerText, 
        imageSrc, 
        navLinks, 
        loginHref, 
        loginText,
        loggedInUser: req.session.user || null 
    });
};

module.exports = { homePage };
