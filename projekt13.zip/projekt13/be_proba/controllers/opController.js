const Termek = require('../models/termekek'); 
exports.getOperator = (req, res) => {
    res.render('operator');
};

exports.operatorTerm = async (req, res) => {
    try {
        const { nev, ar, keszlet, leiras,marka,kategoria,kep } = req.body;

        if (!nev || !ar || !keszlet || !leiras || !marka || !kategoria||!kep) {
            return res.status(400).send('Minden mezőt ki kell tölteni!');
        }
        
        await Termek.create({
            nev,
            ar,
            keszlet,
            leiras, 
            marka,
            kategoria,
            kep
        });

        
        res.redirect('/operator'); 
        
    } catch (err) {
        console.error('Hiba:', err);
        res.status(500).send('Hiba történt a termék hozzáadása során.');
    }
    
};
