const Termek = require('../models/termekek');

exports.getWebshop = async (req, res) => {
    try {
        const products = await Termek.findAll();
        res.render('webshop', { 
            products,
            loggedInUser: req.session.user || null 
        });
    } catch (error) {
        console.error('Hiba a webshop betöltésekor:', error);
        res.status(500).send('Hiba történt a webshop betöltésekor');
    }
};

exports.getTermek = async (req, res) => {
    try {
        const termek = await Termek.findByPk(req.params.id);
        if (!termek) {
            return res.status(404).send('A termék nem található!');
        }
        res.render('termek', { termek });
    } catch (error) {
        console.error('Hiba a termék betöltésekor:', error);
        res.status(500).send('Hiba történt a termék betöltésekor');
    }
};

exports.deleteTermek = async (req, res) => {
    try {
        if (!req.session.user || req.session.user.admin !== 1) {
            return res.status(403).send('Nincs jogosultságod a törléshez!');
        }

        const termekId = req.params.id;
        const termek = await Termek.findByPk(termekId);

        if (!termek) {
            return res.status(404).send('A termék nem található!');
        }

        await termek.destroy();
        res.redirect('/webshop');
    } catch (error) {
        console.error('Hiba a termék törlésekor:', error);
        res.status(500).send('Hiba történt a termék törlésekor');
    }
};


exports.getKosar = async (req, res) => {
    try {
        const kosar = req.session.kosar || [];
        res.render('kosar', { kosar, loggedInUser: req.session.user || null });
    } catch (error) {
        console.error('Hiba a kosár betöltésekor:', error);
        res.status(500).send('Hiba történt a kosár betöltésekor');
    }
};

exports.addToKosar = async (req, res) => {
    try {
        const productId = req.params.id;
        const termek = await Termek.findByPk(productId);

        if (!termek) {
            return res.status(404).send('A termék nem található!');
        }

        if (!req.session.kosar) {
            req.session.kosar = [];
        }

        req.session.kosar.push(termek);
        res.redirect('/webshop');
    } catch (error) {
        console.error('Hiba a termék kosárba tételénél:', error);
        res.status(500).send('Hiba történt a kosárba tételénél');
    }
};

exports.removeFromKosar = (req, res) => {
    const productId = req.params.id;
    req.session.kosar = req.session.kosar.filter(item => item.id !== parseInt(productId));
    res.redirect('/kosar');
};
