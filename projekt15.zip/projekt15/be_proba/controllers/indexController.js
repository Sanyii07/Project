const Ord = require('../models/orders');
const Prod = require('../models/products');
const User = require('../models/users');

const homePage = (req, res) => {
    const headerText = "GymShop";
    const imageSrc = "/img/logokep.jpg"; 
    const loginHref = req.session.user ? '/logout' : '/login';
    const loginText = req.session.user ? 'Kijelentkezés' : 'Bejelentkezés';

    res.render('index', { 
        headerText, 
        imageSrc, 
        loginHref, 
        loginText,
        loggedInUser: req.session.user || null 
    });
};

module.exports = { homePage };
