const User = require('../models/users'); 

exports.getProfilePage = async (req, res) => {
    try {
        if (!req.session.user) {
            return res.redirect('/login');  
        }

        const userEmail = req.session.user.email;
        const user = await User.findOne({ where: { email: userEmail } });

        if (!user) {
            return res.status(404).send('Felhasználó nem található!');
        }

        res.render('profile', {
            user: user,
            loggedInUser: req.session.user
        });
    } catch (error) {
        console.error(error);
        res.status(500).send('Hiba történt a profil lekérésekor.');
    }
};
