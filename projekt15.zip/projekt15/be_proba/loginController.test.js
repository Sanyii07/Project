const request = require('supertest');
const path = require('path');  // A 'path' modul importálása
const app = require(path.join(__dirname, 'index'));
const Users = require('./models/users');
const sequelize = require('./config/database');

// Teszt előtt szinkronizáljuk az adatbázist
beforeAll(async () => {
  try {
    await sequelize.sync({ force: true }); // Az adatbázis szinkronizálása
    await Users.create({
      name: 'Trini Krisztián',
      email: 'tk@tk',
      phone: '1234567890',
      password: 'jelszoteszt',
      admin: 0
    }); // Tesztfelhasználó létrehozása
  } catch (err) {
    console.error('Adatbázis szinkronizálás hiba:', err);
  }
});

// Teszt után adatbázis kapcsolat lezárása
afterAll(async () => {
  await sequelize.close();
});

// Teszt a bejelentkezésre
describe('POST /login', () => {
  it('sikeres bejelentkezés', async () => {
    const response = await request(app)
      .post('/auth')
      .send({
        username: 'tk@tk',  // Tesztfelhasználó emailje
        password: 'jelszoteszt'  // Tesztfelhasználó jelszava
      });

    
    expect(response.status).toBe(302);
    //expect(response.text).toContain('Üdvözlünk!');
  });

  it('hibás jelszó esetén hibát dob', async () => {
    const response = await request(app)
      .post('/auth')
      .send({
        username: 'tk@tk',  // Tesztfelhasználó emailje
        password: 'rosszjelszo'  // Hibás jelszó
      });

    expect(response.status).toBe(400);
    //expect(response.text).toContain('Hibás jelszó!');
  });

  it('nem létező felhasználó esetén hibát dob', async () => {
    const response = await request(app)
      .post('/auth')
      .send({
        username: 'nemtk@tk',  // Nincs ilyen felhasználó
        password: 'nemjelszo'  // Jelszó
      });

    expect(response.status).toBe(401);
    //expect(response.text).toContain('Nincs ilyen felhasználó!');
  });
});
