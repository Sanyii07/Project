const Products = require('../models/products'); 
exports.getOperator = (req, res) => {
    res.render('operator');
};

exports.operatorProd = async (req, res) => {
    try {
        const { name, price, stock, description,brand,category,picture } = req.body;

        if (!name || !price || !stock || !description || !brand || !category|| !picture) {
            return res.status(400).send('Minden mezőt ki kell tölteni!');
        }
        
        await Products.create({
            name,
            price,
            stock,
            description, 
            brand,
            category,
            picture
        });

        
        res.redirect('/operator'); 
        
    } catch (err) {
        console.error('Hiba:', err);
        res.status(500).send('Hiba történt a termék hozzáadása során.');
    }
    
};
