require('dotenv').config();
const express = require('express');
const session = require('express-session');
const app = express();

const sequelize = require('./config/database');
const loginRoutes = require('./routes/loginRoutes');
const regRoutes = require('./routes/regRoutes');
const webRoutes = require('./routes/webRoutes');
const opRoutes = require('./routes/opRoutes');
const indexRoutes= require('./routes/indexRoutes');
const userRoutes = require('./routes/profileRoutes');


app.set('view engine', 'ejs');
app.set('views', './views');

const path = require('path');
const { profile } = require('console');
app.set('views', path.join(__dirname, 'views'));

app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static('public'));

app.use(session({
    secret: 'your_secret_key',
    resave: false,
    saveUninitialized: true,
    cookie: { secure: false }
}));

app.get('/logout', (req, res) => {
    req.session.destroy((err) => {
        if (err) {
            return res.redirect('/error');
        }
        res.redirect('/');
    });
});


app.post('/cart/amount/:id', (req, res) => {
    const productId = req.params.id;
    const action = req.body.action; 

   
    if (!req.session.cart) {
        req.session.cart = [];
    }

    let item = req.session.cart.find(item => item.id === productId); 

    if (item) {
        if (action === 'increase') {
            item.amount += 1; 
        } else if (action === 'decrease' && item.amount > 1) {
            item.amount -= 1; 
        }
    }

    res.redirect('/cart'); 
});


app.get('/cart', (req, res) => {
    const cart = req.session.cart || [];
    res.render('cart', { cart });
});

app.use('/', loginRoutes);
app.use(regRoutes);
app.use(webRoutes);
app.use(opRoutes);
app.use(indexRoutes);
app.use(userRoutes);



const Prod = require('./models/products');
const User = require('./models/users');




sequelize.sync({ force: true }).then(async () => {
    console.log('Adatbázis feltöltése alapadatokkal');


    await Prod.create({name:'100% kreatin-monohidrát',price:'3590',stock:'8',description:'A',brand:'GymBeam',category:'Étrend-kiegészítő',picture:'https://gymbeam.hu/media/catalog/product/cache/bf5a31e851f50f3ed6850cbbf183db11/c/r/creatine_monohydrate_green_apple_250_g_gymbeam.png'});

    await Prod.create({name:'Hidrolizált kollagén',price:'6990',stock:'7',description:'A',brand:'GymBeam',category:'Étrend-kiegészítő',picture:'https://gymbeam.hu/media/catalog/product/cache/bf5a31e851f50f3ed6850cbbf183db11/h/y/hydrolyzed_collagen_runcollg_strawberry-kiwi_500_g_gymbeam.png'});

    await Prod.create({name:'Just Whey',price:'12490',stock:'20',description:'A',brand:'GymBeam',category:'Fehérje',picture:'https://gymbeam.hu/media/catalog/product/cache/bf5a31e851f50f3ed6850cbbf183db11/j/u/just_whey_banana_1_kg_gymbeam.png'});

    await Prod.create({name:'Kettlebell Black',price:'6590',stock:'10',description:'A',brand:'GymBeam',category:'Testúlyok és nehezékek',picture:'https://gymbeam.hu/media/catalog/product/cache/bf5a31e851f50f3ed6850cbbf183db11/4/k/4kg.jpg'});

    await Prod.create({name:'Slimfit Black melegítőnadrág',price:'8190',stock:'25',description:'A',brand:'GymBeam',category:'Fitnesz ruházat',picture:'https://gymbeam.hu/media/catalog/product/cache/bf5a31e851f50f3ed6850cbbf183db11/1/-/1-slimfit-black-sweatpants.jpg'});

    await Prod.create({name:'C-vitamin',price:'4990',stock:'25',description:'A',brand:'GymBeam',category:'Immunerősítő',picture:'https://gymbeam.hu/media/catalog/product/cache/bf5a31e851f50f3ed6850cbbf183db11/n/e/new_vitamin_c.png'});

    await Prod.create({name:'Földimogyoróvaj',price:'17045',stock:'25',description:'A földimogyoróvaj egy ízletes magvaj, amely csak pörkölt földimogyoróból készül. Finom ízének és krémes állagának köszönhetően péksüteményre kenve, kásákhoz adva vagy magában is fogyasztható. Nemcsak a jótékony telítetlen zsírsavak, hanem fehérjeforrás is.',brand:'GymBeam',category:'Fitness élelmiszer',picture:'https://gymbeam.hu/media/catalog/product/cache/bf5a31e851f50f3ed6850cbbf183db11/p/e/peanut_butter_crunchy_340g.png'});

    await Prod.create({name:'ZERO Csokiszirup',price:'1490',stock:'32',description:'A',brand:'GymBeam',category:'Egészséges élelmiszerek',picture:'https://gymbeam.hu/media/catalog/product/cache/bf5a31e851f50f3ed6850cbbf183db11/z/e/zero_sauce_chocolate_320_ml_gymbeam.png'});




    app.listen(3000, () => {
        console.log('A szerver elérhető: http://localhost:3000');
    });
});




