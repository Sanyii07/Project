const request = require('supertest');
const path = require('path');  
const app = require(path.join(__dirname, 'index'));
const Users = require('./models/users');
const sequelize = require('./config/database');


beforeAll(async () => {
  try {
    await sequelize.sync({ force: true }); 
    await Users.create({
      name: 'Trini Krisztián',
      email: 'tk@tk',
      phone: '1234567890',
      password: 'jelszoteszt',
      admin: 0
    }); 
  } catch (err) {
    console.error('Adatbázis szinkronizálás hiba:', err);
  }
});


afterAll(async () => {
  await sequelize.close();
});


describe('POST /login', () => {
  it('sikeres bejelentkezés', async () => {
    const response = await request(app)
      .post('/auth')
      .send({
        username: 'tk@tk',  
        password: 'jelszoteszt'  
      });

    
    expect(response.status).toBe(302);
    
  });

  it('hibás jelszó esetén hibát dob', async () => {
    const response = await request(app)
      .post('/auth')
      .send({
        username: 'tk@tk',  
        password: 'rosszjelszo'  
      });

    expect(response.status).toBe(400);
   
  });

  it('nem létező felhasználó esetén hibát dob', async () => {
    const response = await request(app)
      .post('/auth')
      .send({
        username: 'nemtk@tk', 
        password: 'nemjelszo' 
      });

    expect(response.status).toBe(401);
 
  });
});
