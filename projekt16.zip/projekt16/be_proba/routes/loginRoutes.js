const express = require('express');
const router = express.Router();
const loginController = require('../controllers/loginController');

router.get('/login', loginController.getLoginPage);

router.get('/logout', (req, res) => {
    req.session.destroy(); 
    res.redirect('/login'); 
});


router.post('/auth', loginController.loginUser);

module.exports = router;


