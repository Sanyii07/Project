const express = require('express');
const opController = require('../controllers/opController'); 
const router = express.Router();

router.get('/operator', opController.getOperator);

router.post('/operator', opController.operatorProd);

module.exports = router;