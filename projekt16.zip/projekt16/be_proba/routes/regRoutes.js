const express = require('express');
const regController = require('../controllers/regController'); 
const router = express.Router();

router.get('/register', regController.getRegisterPage);

router.post('/register', regController.registerUser);

module.exports = router;
