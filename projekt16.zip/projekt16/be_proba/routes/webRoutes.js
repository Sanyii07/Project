const express = require('express');
const router = express.Router();
const webController = require('../controllers/webController');

router.get('/webshop', webController.getWebshop);
router.get('/product/:id', webController.getProduct);
router.post('/product/delete/:id', webController.deleteProduct);
router.post('/cart/add/:id', webController.addToCart); 
router.get('/cart', webController.getCart); 
router.post('/cart/delete/:id', webController.removeFromCart); 

module.exports = router;
