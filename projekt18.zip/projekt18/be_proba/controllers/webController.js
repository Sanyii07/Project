const Product = require('../models/products');

exports.getWebshop = async (req, res) => {
    try {
        const products = await Product.findAll();
        res.render('webshop', { 
            products,
            loggedInUser: req.session.user || null 
        });
    } catch (error) {
        console.error('Hiba a webshop betöltésekor:', error);
        res.status(500).send('Hiba történt a webshop betöltésekor');
    }
};

exports.getProduct = async (req, res) => {
    try {
        const product = await Product.findByPk(req.params.id);
        if (!product) {
            return res.status(404).send('A termék nem található!');
        }
        res.render('product', { product });
    } catch (error) {
        console.error('Hiba a termék betöltésekor:', error);
        res.status(500).send('Hiba történt a termék betöltésekor');
    }
};

exports.deleteProduct = async (req, res) => {
    try {
        if (!req.session.user || req.session.user.admin !== 1) {
            return res.status(403).send('Nincs jogosultságod a törléshez!');
        }

        const productId = req.params.id;
        const product = await Product.findByPk(productId);

        if (!product) {
            return res.status(404).send('A termék nem található!');
        }

        await product.destroy();
        res.redirect('/webshop');
    } catch (error) {
        console.error('Hiba a termék törlésekor:', error);
        res.status(500).send('Hiba történt a termék törlésekor');
    }
};


exports.getCart = async (req, res) => {
    try {
        const cart = req.session.cart || [];
        res.render('cart', { cart, loggedInUser: req.session.user || null });
    } catch (error) {
        console.error('Hiba a kosár betöltésekor:', error);
        res.status(500).send('Hiba történt a kosár betöltésekor');
    }
};

exports.addToCart = async (req, res) => {
    try {
        const productId = req.params.id;
        const product = await Product.findByPk(productId);

        if (!product) {
            return res.status(404).send('A termék nem található!');
        }

        if (!req.session.cart) {
            req.session.cart = [];
        }

        req.session.cart.push(product);
        res.redirect('/webshop');
    } catch (error) {
        console.error('Hiba a termék kosárba tételénél:', error);
        res.status(500).send('Hiba történt a kosárba tételénél');
    }
};

exports.removeFromCart = (req, res) => {
    const productId = req.params.id;
    req.session.cart = req.session.cart.filter(item => item.id !== parseInt(productId));
    res.redirect('/cart');
};
