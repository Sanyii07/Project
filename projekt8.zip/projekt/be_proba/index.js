require('dotenv').config();
const express = require('express');
const session = require('express-session');
const app = express();

const sequelize = require('./config/adatbazis');
const loginRoutes = require('./routes/loginRoutes');
const regRoutes = require('./routes/regRoutes');
const webRoutes = require('./routes/webRoutes');
const opRoutes = require('./routes/opRoutes');
const homeRoutes= require('./routes/homeRoutes')


app.set('view engine', 'ejs');
app.set('views', './views');

const path = require('path');
const { profile } = require('console');
app.set('views', path.join(__dirname, 'views'));

app.use(express.urlencoded({ extended: true }));
app.use(express.static('public'));

app.use(session({
    secret: 'your_secret_key',
    resave: false,
    saveUninitialized: true,
    cookie: { secure: false }
}));

app.get('/logout', (req, res) => {
    req.session.destroy((err) => {
        if (err) {
            return res.redirect('/error');
        }
        res.redirect('/');
    });
});

// Kosárba tett termékek kezelése (mennyiség növelés és csökkentés)
app.post('/kosar/mennyiseg/:id', (req, res) => {
    const productId = req.params.id;
    const action = req.body.action; // "increase" vagy "decrease"

    // Ha nincs kosár a session-ben, létrehozzuk
    if (!req.session.kosar) {
        req.session.kosar = [];
    }

    let item = req.session.kosar.find(item => item.id === productId); // Keressük a terméket a kosárban

    if (item) {
        if (action === 'increase') {
            item.mennyiseg += 1; // Mennyiség növelése
        } else if (action === 'decrease' && item.mennyiseg > 1) {
            item.mennyiseg -= 1; // Mennyiség csökkentése, minimum 1
        }
    }

    res.redirect('/kosar'); // Vissza a kosár oldalra
});

// Kosár oldal megjelenítése
app.get('/kosar', (req, res) => {
    const kosar = req.session.kosar || [];
    res.render('kosar', { kosar });
});

app.use('/', loginRoutes);
app.use(regRoutes);
app.use(webRoutes);
app.use(opRoutes);
app.use(homeRoutes);


sequelize.sync({ force: false }).then(async () => {
    console.log('Adatbázis feltöltése alapadatokkal');
    app.listen(3000, () => {
        console.log('A szerver elérhető: http://localhost:3000');
    });
});
