const { DataTypes } = require('sequelize');
const sequelize = require('../config/adatbazis');
const Termek = require('./termekek');
const Vasarlo = require('./vasarlok');


const Rendelések = sequelize.define('rendelesek', {
  id: {
    type: DataTypes.INTEGER,
    allowNull: false,
    autoIncrement: true,
    primaryKey: true,
  },
  vasarloId: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: 'vasarlok', 
      key: 'id',
    },
  },
  termekId: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: 'termekek', 
      key: 'id',
    },
  },
  egysegar: {
    type: DataTypes.INTEGER,
    allowNull: false,
  },
  idopont: {
    type: DataTypes.DATE,
    allowNull: false,
  },
  mennyiseg: {
    type: DataTypes.INTEGER,
    allowNull: false,
  },
}, {
  freezeTableName: true,
  timestamps: false,
});



module.exports = Rendelések;

