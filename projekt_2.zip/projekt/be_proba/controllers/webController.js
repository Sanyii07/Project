const Termekek = require('../models/termekek');

// Webshop termékek lekérése
exports.getWebshop = async (req, res) => {
    try {
        const products = await Termekek.findAll();
        res.render('webshop', { products });
    } catch (error) {
        console.error('Hiba a webshop betöltésekor:', error);
        res.status(500).send('Hiba történt a webshop betöltésekor');
    }
};

// Új termék hozzáadása (Operátor funkció)
exports.addProduct = async (req, res) => {
    try {
        const { nev, ar, keszlet, leiras, marka, kategoria } = req.body;

        await Termekek.create({
            nev,
            ar,
            keszlet,
            leiras,
            marka,
            kategoria
        });

        res.redirect('/webshop');
    } catch (error) {
        console.error('Hiba történt a termék hozzáadásakor:', error);
        res.status(500).send('Hiba történt a termék hozzáadásakor');
    }
};
