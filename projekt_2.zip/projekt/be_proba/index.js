require('dotenv').config();
const express = require('express');
const session = require('express-session');
const app = express();

const sequelize = require('./config/adatbazis');
const loginRoutes = require('./routes/loginRoutes');
const regRoutes = require('./routes/regRoutes');
const webRoutes = require('./routes/webRoutes');
const opRoutes = require('./routes/opRoutes')


app.set('view engine', 'ejs');
app.set('views', './views');

const path = require('path');
app.set('views', path.join(__dirname, 'views'));

app.use(express.urlencoded({ extended: true }));
app.use(express.static('public'));

app.use(session({
    secret: 'your_secret_key',
    resave: false,
    saveUninitialized: true,
    cookie: { secure: false }
}));

app.get('/logout', (req, res) => {
    // Session törlése
    req.session.destroy((err) => {
        if (err) {
            return res.redirect('/error');
        }
        // Visszairányítjuk a kezdőlapra
        res.redirect('/');
        
    });
});

app.use('/', loginRoutes);
app.use(regRoutes);
app.use(webRoutes);
app.use(opRoutes);


const Rend = require('./models/rendelesek');
const Term = require('./models/termekek');
const Vasa = require('./models/vasarlok');

sequelize.sync({ force: false }).then(async () => {
    console.log('Adatbázis feltöltése alapadatokkal');

    app.get('/', (req, res) => {
        const headerText = "Év végi Projekt";
        const imageSrc = 'kep3.jpg'; // Alapértelmezett kép
        const navLinks = [
            { href: '/kapcsolat', text: 'Kapcsolat' },
            { href: '/tortenet', text: 'Történetünk' }
        ];
        const loginHref = req.session.user ? '/logout' : '/login';
        const loginText = req.session.user ? 'Kijelentkezés' : 'Bejelentkezés';

        res.render('index', { 
            headerText, 
            imageSrc, 
            navLinks, 
            loginHref, 
            loginText,
            loggedInUser: req.session.user || null // Átadjuk a bejelentkezett felhasználó adatait
        });
    });

    app.listen(3000, () => {
        console.log('A szerver elérhető: http://localhost:3000');
    });
});
