const express = require('express');
const opController = require('../controllers/opController'); // Regisztrációs controller importálása
const router = express.Router();

// Regisztrációs oldal megjelenítése (GET kérés)
router.get('/operator', opController.getOperator);

// Regisztrációs adatok feldolgozása (POST kérés)
router.post('/operator', opController.operatorTerm);

module.exports = router;