const express = require('express');
const router = express.Router();
const webController = require('../controllers/webController');

router.get('/webshop', webController.getWebshop);
router.post('/webshop/add', webController.addProduct); // Operátor funkció

module.exports = router;
