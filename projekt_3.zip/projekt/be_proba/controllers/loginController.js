const Vasarlo = require('../models/vasarlok'); // Vasarlo modell importálása

// Bejelentkezési oldal megjelenítése
exports.getLoginPage = (req, res) => {
    res.render('login', {
        title: 'Bejelentkezés',
        loginMessage: 'Kérlek, jelentkezz be!'
    });
};

// Bejelentkezés feldolgozása
exports.loginUser = async (req, res) => {
    try {
        console.log(req.session);

        const { username, password } = req.body;

        // Ellenőrizzük, hogy a felhasználó létezik-e
        const user = await Vasarlo.findOne({ where: { email: username } });

        if (!user) {
            return res.render('login', {
                loginMessage: 'Nincs ilyen felhasználó!'
            });
        }

        // Ha a jelszó helyes
        if (user.jelszo === password) {
            // Felhasználói adatok mentése a session-be
            req.session.user = { username: user.nev, email: user.email };

            // Átirányítás a főoldalra vagy védett oldalra
            return res.redirect('/');
        } else {
            return res.render('login', {
                loginMessage: 'Hibás jelszó!'
            });
        }
    } catch (err) {
        console.error(err);
        res.status(500).send('Hiba történt a bejelentkezés során.');
    }
};

exports.getIndexPage = (req, res) => {
    res.render('index', {
        navLinks: [
            { href: '/about', text: 'Rólunk' },
            { href: '/contact', text: 'Kapcsolat' }
        ],
        headerText: 'Üdvözlünk!',
        imageSrc: '/img/logo.png',
        loginHref: req.session.user ? '/logout' : '/login',
        loginText: req.session.user ? 'Kijelentkezés' : 'Bejelentkezés',
        loggedInUser: req.session.user || null
    });
};