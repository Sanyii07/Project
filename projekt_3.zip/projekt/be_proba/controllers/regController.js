const Vasarlo = require('../models/vasarlok'); // Vasarlo modell importálása

// Regisztrációs oldal megjelenítése (GET kérés)
exports.getRegisterPage = (req, res) => {
    res.render('register');
};

// Regisztrációs adatok feldolgozása (POST kérés)
exports.registerUser = async (req, res) => {
    try {
        const { nev, email, telszam, jelszo } = req.body;

        // Ellenőrizzük, hogy minden mező ki van-e töltve
        if (!nev || !email || !telszam || !jelszo) {
            return res.status(400).send('Minden mezőt ki kell tölteni!');
        }

        // Ellenőrizzük, hogy a felhasználónév vagy email már létezik-e
        const existingUser = await Vasarlo.findOne({ where: { email } });
        if (existingUser) {
            return res.status(400).send('Ez az email cím már regisztrálva van!');
        }

        // Új vásárló létrehozása a vasarlok táblában
        await Vasarlo.create({
            nev,
            email,
            telszam,
            jelszo, // Jelszó tárolása (nem titkosítva)
        });

        //res.send('Sikeres regisztráció!');
        res.redirect('/'); 
        
    } catch (err) {
        console.error('Hiba:', err);
        res.status(500).send('Hiba történt a regisztráció során.');
    }
    
};
