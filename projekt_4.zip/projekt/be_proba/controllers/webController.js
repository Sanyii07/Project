const Termek = require('../models/termekek');

exports.getWebshop = async (req, res) => {
    try {
        const products = await Termek.findAll();
        res.render('webshop', { 
            products,
            loggedInUser: req.session.user || null // Bejelentkezett felhasználó átadása
        });
    } catch (error) {
        console.error('Hiba a webshop betöltésekor:', error);
        res.status(500).send('Hiba történt a webshop betöltésekor');
    }
};

exports.getTermek = async (req, res) => {
    try {
        const termek = await Termek.findByPk(req.params.id);
        if (!termek) {
            return res.status(404).send('A termék nem található!');
        }
        res.render('termek', { termek });
    } catch (error) {
        console.error('Hiba a termék betöltésekor:', error);
        res.status(500).send('Hiba történt a termék betöltésekor');
    }
};
