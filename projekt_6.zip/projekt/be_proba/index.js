require('dotenv').config();
const express = require('express');
const session = require('express-session');
const app = express();

const sequelize = require('./config/adatbazis');
const loginRoutes = require('./routes/loginRoutes');
const regRoutes = require('./routes/regRoutes');
const webRoutes = require('./routes/webRoutes');
const opRoutes = require('./routes/opRoutes');
const homeRoutes= require('./routes/homeRoutes')

app.set('view engine', 'ejs');
app.set('views', './views');

const path = require('path');
app.set('views', path.join(__dirname, 'views'));

app.use(express.urlencoded({ extended: true }));
app.use(express.static('public'));

app.use(session({
    secret: 'your_secret_key',
    resave: false,
    saveUninitialized: true,
    cookie: { secure: false }
}));

app.get('/logout', (req, res) => {
    req.session.destroy((err) => {
        if (err) {
            return res.redirect('/error');
        }
        res.redirect('/');
    });
});

app.use('/', loginRoutes);
app.use(regRoutes);
app.use(webRoutes);
app.use(opRoutes);
app.use(homeRoutes);



sequelize.sync({ force: false }).then(async () => {
    console.log('Adatbázis feltöltése alapadatokkal');
    app.listen(3000, () => {
        console.log('A szerver elérhető: http://localhost:3000');
    });
});
