const { DataTypes } = require('sequelize');
const sequelize = require('../config/adatbazis');

const Termekek = sequelize.define('termekek', {
  id: {
    type: DataTypes.INTEGER,
    allowNull: false,
    autoIncrement: true,
    primaryKey: true,
  },
  nev: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  ar: {
    type: DataTypes.INTEGER,
    allowNull: false,
  },
  keszlet: {
    type: DataTypes.INTEGER,
    allowNull: false,
  },
  leiras: {
    type: DataTypes.TEXT,
    allowNull: true,
  },
  marka: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  kategoria: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  image: {
    type: DataTypes.TEXT, // Base64 képként tároljuk
    allowNull: true,
  }
}, {
  freezeTableName: true,
  timestamps: false,
});

module.exports = Termekek;
