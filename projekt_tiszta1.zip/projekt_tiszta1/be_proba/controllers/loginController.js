const Vasarlo = require('../models/users'); 


exports.getLoginPage = (req, res) => {
    res.render('login', {
        title: 'Bejelentkezés',
        loginMessage: 'Kérlek, jelentkezz be!'
    });
};


exports.loginUser = async (req, res) => {
    try {
        console.log(req.session);

        const { username, password } = req.body;

        const user = await Vasarlo.findOne({ where: { email: username } });

        if (!user) {
            return res.render('login', {
                loginMessage: 'Nincs ilyen felhasználó!'
            });
        }

        if (user.jelszo === password) {
            req.session.user = { 
                username: user.nev, 
                email: user.email,
                admin: user.admin  
            };

            if (user.admin === 1) {
                console.log('Admin felhasználó jelentkezett be');
            }

            return res.redirect('/');  
        } else {
            return res.render('login', {
                loginMessage: 'Hibás jelszó!'
            });
        }
    } catch (err) {
        console.error(err);
        res.status(500).send('Hiba történt a bejelentkezés során.');
    }
};

exports.getIndexPage = (req, res) => {
    res.render('index', {
        navLinks: [
            { href: '/about', text: 'Rólunk' },
            { href: '/contact', text: 'Kapcsolat' }
        ],
        headerText: 'Üdvözlünk!',
        imageSrc: '/img/logo.png',
        loginHref: req.session.user ? '/logout' : '/login',
        loginText: req.session.user ? 'Kijelentkezés' : 'Bejelentkezés',
        loggedInUser: req.session.user || null
    });
};
