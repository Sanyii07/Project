const Vasarlo = require('../models/users'); 

exports.getRegisterPage = (req, res) => {
    res.render('register');
};

exports.registerUser = async (req, res) => {
    try {
        const { nev, email, telszam, jelszo } = req.body;

        if (!nev || !email || !telszam || !jelszo) {
            return res.status(400).send('Minden mezőt ki kell tölteni!');
        }

        const existingUser = await Vasarlo.findOne({ where: { email } });
        if (existingUser) {
            return res.status(400).send('Ez az email cím már regisztrálva van!');
        }

        await Vasarlo.create({
            nev,
            email,
            telszam,
            jelszo, 
        });

        res.redirect('/'); 
        
    } catch (err) {
        console.error('Hiba:', err);
        res.status(500).send('Hiba történt a regisztráció során.');
    }
    
};
