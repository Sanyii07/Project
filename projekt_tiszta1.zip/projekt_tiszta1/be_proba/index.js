require('dotenv').config();
const express = require('express');
const session = require('express-session');
const app = express();

const sequelize = require('./config/adatbazis');
const loginRoutes = require('./routes/loginRoutes');
const regRoutes = require('./routes/regRoutes');
const webRoutes = require('./routes/webRoutes');
const opRoutes = require('./routes/opRoutes');
const homeRoutes= require('./routes/homeRoutes');
const userRoutes = require('./routes/profileRoutes');


app.set('view engine', 'ejs');
app.set('views', './views');

const path = require('path');
const { profile } = require('console');
app.set('views', path.join(__dirname, 'views'));

app.use(express.urlencoded({ extended: true }));
app.use(express.static('public'));

app.use(session({
    secret: 'your_secret_key',
    resave: false,
    saveUninitialized: true,
    cookie: { secure: false }
}));

app.get('/logout', (req, res) => {
    req.session.destroy((err) => {
        if (err) {
            return res.redirect('/error');
        }
        res.redirect('/');
    });
});


app.post('/cart/mennyiseg/:id', (req, res) => {
    const productId = req.params.id;
    const action = req.body.action; 

   
    if (!req.session.cart) {
        req.session.cart = [];
    }

    let item = req.session.cart.find(item => item.id === productId); 

    if (item) {
        if (action === 'increase') {
            item.mennyiseg += 1; 
        } else if (action === 'decrease' && item.mennyiseg > 1) {
            item.mennyiseg -= 1; 
        }
    }

    res.redirect('/cart'); 
});


app.get('/cart', (req, res) => {
    const cart = req.session.cart || [];
    res.render('cart', { cart });
});

app.use('/', loginRoutes);
app.use(regRoutes);
app.use(webRoutes);
app.use(opRoutes);
app.use(homeRoutes);
app.use(userRoutes);


sequelize.sync({ force: false }).then(async () => {
    console.log('Adatbázis feltöltése alapadatokkal');
    app.listen(3000, () => {
        console.log('A szerver elérhető: http://localhost:3000');
    });
});
