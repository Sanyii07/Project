const express = require('express');
const router = express.Router();
const webController = require('../controllers/webController');

router.get('/webshop', webController.getWebshop);
router.get('/product/:id', webController.getProduct);
router.post('/product/torles/:id', webController.deleteProduct);
router.post('/cart/hozzaad/:id', webController.addToCart); 
router.get('/cart', webController.getCart); 
router.post('/cart/torles/:id', webController.removeFromCart); 

module.exports = router;
